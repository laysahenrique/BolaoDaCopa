package com.laysafontoura.model;

import org.springframework.data.repository.CrudRepository;


//Interface para fazer CRUD

public interface NationalTeamRepository extends CrudRepository<NationalTeam, Long>{
    
}