package com.laysafontoura.model;

public interface Playoffs{
    public Boolean nextStage(Boolean x);
    public Boolean toEliminate(Boolean x);
}